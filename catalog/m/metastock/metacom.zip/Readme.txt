This zip file contains
1 Directory with 5 field data files old format
1 Directory with 7 field data files old format
1 Exe for testing data
1 Directory (65.zip) new format that contains both
  day and intraday data mixed directory.
1 Directory 65287.zip new intraday data single directory
1 Directory 65246.zip new intraday data single directory
1 Directory 65328.zip new intraday data single directory
1 Doc file with info on Metastock/Computrac files Format. 

If you don`t have microsoft word look for the word viewer
that comes bundled with your software.
If you still don`t have it then don`t worry i`ll send you
the info that wordpad can read.