/*====================================================================*/
/*         MPEG-4 Audio (ISO/IEC 14496-3) Copyright Header            */
/*====================================================================*/
/*
This software module was originally developed by Rakesh Taori and Andy
Gerrits (Philips Research Laboratories, Eindhoven, The Netherlands) in
the course of development of the MPEG-4 Audio (ISO/IEC 14496-3). This
software module is an implementation of a part of one or more MPEG-4
Audio (ISO/IEC 14496-3) tools as specified by the MPEG-4 Audio
(ISO/IEC 14496-3). ISO/IEC gives users of the MPEG-4 Audio (ISO/IEC
14496-3) free license to this software module or modifications thereof
for use in hardware or software products claiming conformance to the
MPEG-4 Audio (ISO/IEC 14496-3). Those intending to use this software
module in hardware or software products are advised that its use may
infringe existing patents. The original developer of this software
module and his/her company, the subsequent editors and their
companies, and ISO/IEC have no liability for use of this software
module or modifications thereof in an implementation. Copyright is not
released for non MPEG-4 Audio (ISO/IEC 14496-3) conforming products.
CN1 retains full right to use the code for his/her own purpose, assign
or donate the code to a third party and to inhibit third parties from
using the code for non MPEG-4 Audio (ISO/IEC 14496-3) conforming
products.  This copyright notice must be included in all copies or
derivative works. Copyright 1996.
*/

/* HP 980505   added extern "C" */

#define NLEVELS (ORDER_LPC+1)
#define MAX_VLC_LEN   16
#define MAX_VLC_BITS  4

#ifdef __cplusplus
extern "C" {
#endif

int gen_vlc_tables(int max_tbls,int idcs,int idx_to_lvls[],int nsamples[],short
count[ORDER_LPC+1][36],int maxvlclen,int lbits,int tbl_idx[],int cwl[],int ltbl[NLEVELS][MAX_VLC_LEN],int rice[],int
cmt[]);
void huff_len_to_cwrds(int n, short codesize[], long cwrds[]);
void a_tab_encode(int value,int K, int ltbl[], long *cw, short *length);
int a_tab_decode(int K, int ltbl[], long bits, short length);
void hufflen(int n,short freq[],short codesize[]);
void get_huffman_bits(int n, long *val, short *codesize, long *codeword, long bits, short
length);

#ifdef __cplusplus
}
#endif
