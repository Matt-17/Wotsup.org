
Sample RTF Reader Kit
=====================

This directory contains files necessary to build 16 and 32-bit versions
of a sample RTF reader.

Building the 16-bit version requires Microsoft C8 (VC1.5).
Building the 32-bit version requires Microsoft C9 (VC2.0) or later.

The sample RTF reader is described more fully in "Appendix A" of the
RTF Specification, version 1.5.

