/****************************************
 *
 * load Pharlap relocatable executables
 *
 ****************************************/

#include <stdio.h>
#include <malloc.h>
#include <string.h>

#define REX_MAGIC					'QM'

typedef unsigned char				BYTE;
typedef unsigned short				WORD;
typedef unsigned long				DWORD;
typedef enum { FALSE = 0, TRUE }	BOOL;

typedef struct
{
	WORD	magic;
	WORD	lastSecLen;
	WORD	secCnt;
	WORD	relocs;
	WORD	imageOfs;
	WORD	pages;
	WORD	maxAlloc;
	DWORD	initESP;
	WORD	checksum;
	DWORD	initEIP;
	WORD	relocOfs;
	WORD	overlay;
}
REX_HEADER;

/**************************************************
 *
 * allocate memory, load and relocate a REX image
 *
 **************************************************/

BOOL LoadModule(const char *name, BYTE **memBlk, DWORD *initEIP)
{
	DWORD filSz, imgOfs, imgSz, bssSz, reloc;
	REX_HEADER rex;
	WORD loop;
	BYTE *mem;
	FILE *mod;

	// open file

	mod = fopen(name, "rb");
	if(!mod)
	{
		return TRUE;
	}

	// check it looks like a REX

	if(fread(&rex, 1, sizeof(REX_HEADER), mod) != sizeof(REX_HEADER) ||
		rex.magic != REX_MAGIC)
	{
		fclose(mod);
		return TRUE;
	}

	// allocate memory for image

	imgOfs = (DWORD) rex.imageOfs << 4;
	filSz = ((DWORD)(rex.secCnt - (rex.lastSecLen ? 1 : 0)) << 9) +
		rex.lastSecLen;
	imgSz = filSz - imgOfs;
	bssSz = (DWORD)(rex.pages + 1) << 12;
	mem = (BYTE *) malloc(imgSz + bssSz);
	if(!mem)
	{
		fclose(mod);
		return TRUE;
	}

	// zero the BSS

	memset(mem + imgSz, 0, bssSz);

	// load the image

	fseek(mod, imgOfs, SEEK_SET);
	if(fread(mem, 1, imgSz, mod) != imgSz)
	{
		free(mem);
		fclose(mod);
		return TRUE;
	}

	// apply relocations

	fseek(mod, rex.relocOfs, SEEK_SET);
	for(loop = 0; loop < rex.relocs; ++loop)
	{
		if(fread(&reloc, 1, sizeof(DWORD), mod) != sizeof(DWORD))
		{
			free(mem);
			fclose(mod);
			return TRUE;
		}
		*(DWORD *)(mem + (reloc & 0x7fffffff)) += (DWORD) mem;
	}

	// return details

	fclose(mod);
	*memBlk = mem;
	*initEIP = rex.initEIP;
	return FALSE;
}

/***********************************
 *
 * demonstrate use of LoadModule()
 *
 ***********************************/

#include "impexp.h"
#include "conio.h"

typedef IMPORT *(*INIT_FUNC)(EXPORT *);

IMPORT *imports;
EXPORT exports = {
	printf,
	getch
};

void main(void)
{
	INIT_FUNC go_rex;
	BYTE *mem;
	DWORD eip;

	if(LoadModule("demo.rex", &mem, &eip))
	{
		printf("!! load failed !!");
		return;
	}

	go_rex = (INIT_FUNC)(mem + eip);
	imports = go_rex(&exports);

	imports->do_stuff();
	imports->do_other_stuff();

	free(mem);
}

