#ifndef _IMPEXP_H_
#define _IMPEXP_H_

typedef struct
{
	void (*do_stuff)(void);
	void (*do_other_stuff)(void);
}
#ifdef REX
EXPORT;
#else
IMPORT;
#endif

typedef struct
{
	int (*printf)(const char *, ...);
	int (*getch)(void);
}
#ifdef REX
IMPORT;
#else
EXPORT;
#endif

#endif
