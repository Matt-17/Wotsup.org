#include <stdio.h>
#include <conio.h>

#define REX
#include "impexp.h"

IMPORT *imports;

void do_stuff(void)
{
	imports->printf("we are now in do_stuff(). press a key\n");
	imports->getch();
}

void do_other_stuff(void)
{
	imports->printf("we are now in do_other_stuff. press a key\n");
	imports->getch();
}

EXPORT exports = {
	do_stuff,
	do_other_stuff
};

EXPORT *rex_main(IMPORT *imp)
{
	imports = imp;
	return &exports;
}

