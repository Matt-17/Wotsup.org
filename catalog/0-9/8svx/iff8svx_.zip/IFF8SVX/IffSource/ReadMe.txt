IFF 8SVX File Write/Read Routines
=================================

Disclaimer:
-----------
I hereby give this code to the general public, as is, with no guarantees whatsoever.
This code has not yet been tested: Use at your own risk!

Information:
------------
Two C headers and sources are included within that allow the reading and writing of IFF 8SVX Files only (no playback or recording routines are included since they are system dependent). The IFF.C and IFF.H have been written as basic, general IFF read/write routines (note that LISTs, CATs, and PROPs are not handled since they are beyond the scope of my programming requirements). I leave it up to you to create the source capable of extracting the information within the memory chunks in a way which can be utilized for your purposes.

Although the Fibonacci-Delta Decompression algorithm has been given, no information is given on how to accomplish Fibonacci-Delta Compression. It may simply be an inverse process of the decompression, but I wouldn't bank on it.

You may correct and modify the code as you wish with no restrictions.

Robert M. Templeton
November 26, 1996
