/*
	types.h
	basic type definitions
	11.22.96

   Robert M. Templeton
*/
#ifndef TYPES_H
#define TYPES_H

#define ucase(c) 				((((c) >= 97) && ((c) <= 122)) ? (c)-32 : (c))

/* More-meaningful Types */
/* char */
typedef unsigned char    uchar;
/* int */
typedef unsigned int      uint;
typedef short             word;
typedef unsigned short   uword;
/* long */
typedef unsigned long    ulong;
typedef char           *string;
typedef unsigned char *ustring;
typedef void			  *memptr;

#endif /* TYPES_H */

