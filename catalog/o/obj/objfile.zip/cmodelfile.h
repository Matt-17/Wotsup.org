/******************************************************************************
**
** CModelFile.h
**
** Purpose: Abstract Base Class to be inherited by all classes which wish to
**		load a 3D model from different types of files.  Allows the Engine to
**		use all 3D models without having to worry about what type of files they
**		came from.
**
** Modification History:
**		11/18/00 created by VenTure
**
** Copyright: (c) 2000 Justin S. Houk, jhouk@mailcity.com.  Permission to use 
** and modify freely given so long as this original copyright notice remains 
** unchanged.
**
******************************************************************************/

#ifndef _MODELFILE_H_
#define _MODELFILE_H_

struct Vertex
{
	float x, y, z;
};

struct VertexTexture
{
	float u, v, w;
};

struct VertexNormal
{
	float i, j, k;
};

class CModelFile
{
public:
	virtual int GetNumMeshPoints() const = 0;

	virtual const Vertex* GetMeshVertex(int i) const = 0;

	virtual int GetNumFaces() = 0;

	virtual bool HasTextureCoords() const = 0;

	virtual int GetNumVertsPerFace() = 0;

	virtual int GetFaceVertexIndex(int face, int vertex) = 0;
	virtual int GetFaceTextureVertexIndex(int face, int vertex) = 0;
	virtual int GetFaceNormalVertexIndex(int face, int vertex) = 0;

	virtual const Vertex* GetFaceVertex(int face, int vertex) = 0;
	virtual const VertexTexture* GetFaceTextureVertex(int face, int vertex) = 0;
	virtual const VertexNormal* GetFaceNormalVertex(int face, int vertex) = 0;
};


#endif