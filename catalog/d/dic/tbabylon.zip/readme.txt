TBabylon V1.0
-------------
I don't know if any1 will care, but I write it anyhow...
I created TBabylon, because there was no NORMAL dictionary I could use
for some experimentation I needed to do with dictionaries.
It reads Babylon's old .dic files, many of which could be found at
http://www1.futureware.at/1dim.htm
It translates from any non-hebrew language (currently hard-coded to english,
but its not that hard to change) to any language (including hebrew...)
I tested it only on engtoheb.dic and engtoger.dic (the languages I know...).
It also requires english.dic to be present ofcourse.
The code's HEAVILY documented, so I doubt I need to explain how it works...
If any questions arise, write to me, I'll try to answer...
If  you use it in any app you write, remember the dictionaries may be
copyrighted, and you may need to get a license from babylon...
If you write anything cool (you can also use it as a speller you know :),
I'll love to hear about it.

        regards

                                Oren J. Maurice
                                moonie@doglover.com
                                oren@visititle.com
                                
