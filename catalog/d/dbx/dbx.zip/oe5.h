typedef struct {
	long lFilePos;
        long lFlags;
        long lSectionSize;
        long lNextHeader;
} oe5__message_header;

typedef struct {
	long     lFilePos;
        long     lLength;
        char     Unknown[17];
        long     lPos;
} oe5__message_table;

typedef struct {
	long lTable;
        long lMessage;
} oe5__message_dir;

