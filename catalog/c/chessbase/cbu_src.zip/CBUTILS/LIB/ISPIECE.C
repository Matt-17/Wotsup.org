#include "global.h"

/*
 * ISPIECE
 *
 * Test if a character is a valid piece type.
 */
int
ispiece(c)
	char c;
{
	int i;

	for (i = 1; i <= 6; i++)
		if (*(piece_list + i) == c)
			return 1;
	return 0;
}
