#include "global.h"

/*
 * GAME_TIDY
 *
 * Tidy up a game structure
 */
void
game_tidy(game)
    Game game;
{
    if (game->moves)
        free(game->moves);
    if (game->comments)
        free(game->comments);
    bzero((char *) game, sizeof(struct game));
}
