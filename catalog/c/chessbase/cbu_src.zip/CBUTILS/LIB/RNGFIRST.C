#include "global.h"
#include <ctype.h>

u_long
range_first(string)
    char *string;
{
    char *endptr;
    u_long ret;

    if (isdigit(*string)) {
        ret = (u_long) strtol(string, &endptr, 10);
        if (*endptr != '-' && *endptr != '\0')
            return 0L;
        return ret;
    } else if (*string == '-')
        return 1L;
    return 0L;
}
