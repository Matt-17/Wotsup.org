#include "global.h"

/*
 * C2L
 *
 * Convert an array of bytes into an unsigned long in big-endian format.
 */
u_long
c2l(c)
    u_char *c;
{
    register u_long ret;

    ret = (u_long) * c++ << 24;
    ret |= (u_long) * c++ << 16;
    ret |= (u_long) * c++ << 8;
    ret |= (u_long) * c;
    return ret;
}
