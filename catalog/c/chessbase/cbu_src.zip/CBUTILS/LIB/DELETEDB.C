#include "global.h"

/*
 * DELETE_DATABASE
 *
 * Remove game and index file for database
 */
int
delete_database(db)
    Database db;
{
    int ret;

    ret = file_delete(db->cbf);
    ret += file_delete(db->cbi);
    return ret;
}
