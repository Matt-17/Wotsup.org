#include "global.h"

u_char gamebuf[128] = "";              /* read/write workspace */
int ignore_chksum_err = 0;             /* ignore checksum errors */
int chksum_err = 0;                    /* non-zero if a checksum error
                                          occurred */
