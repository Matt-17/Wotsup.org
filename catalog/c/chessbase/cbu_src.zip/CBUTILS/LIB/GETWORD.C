#include "global.h"
#include <ctype.h>

/*
 * GET_WORD
 *
 * Locate the next word in a string and return a pointer to it, and it's
 * size.
 */
char *
get_word(s, len)
    char *s;
    int *len;
{
    int wlen;
    char *ret;

    wlen = 0;
    while (*s && isspace(*s))
        s++;
    ret = s;
    while (*s && !isspace(*s)) {
        s++;
        wlen++;
    }
    if (len)
        *len = wlen;
    if (!wlen)
        ret = NULL;
    return ret;
}
