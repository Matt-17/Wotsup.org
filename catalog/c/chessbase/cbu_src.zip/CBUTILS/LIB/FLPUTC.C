#include "global.h"

/*
 * FILE_PUTC
 *
 * Put a character to a file.
 */
int
file_putc(file, c)
    File file;
    int c;
{
    int ret;
    char buffer;

    buffer = (char) c;
    ret = write(file->fd, &buffer, 1);
    if (ret != 1)
        error("error writing file \"%s\"", file->name);
    return ret;
}
