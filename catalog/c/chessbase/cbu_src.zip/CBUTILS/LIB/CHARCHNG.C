#include "global.h"

/*
 * CHAR_CHANGE
 *
 * Change all occurances of 'c1' to 'c2' in string 's'.
 */
void
char_change(s, c1, c2)
    char *s, c1, c2;
{
    while (*s) {
        if (*s == c1)
            *s = c2;
        s++;
    }
}
