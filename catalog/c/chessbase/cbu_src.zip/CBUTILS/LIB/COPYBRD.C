#include "global.h"

/*
 * COPY_BOARD
 *
 * Copy one board to another
 */
void
copy_board(source, destination)
    u_char *source, *destination;
{
    bcopy(source, destination, 64);
}
