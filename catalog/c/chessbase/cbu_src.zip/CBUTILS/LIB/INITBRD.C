#include "global.h"

static char first[8] = {
    ROOK, KNIGHT, BISHOP, QUEEN, KING, BISHOP, KNIGHT, ROOK
};

/*
 * INIT_BOARD
 *
 * Initialise pieces on board.
 */
void
init_board(board)
    u_char *board;
{
    int i;

    for (i = 0; i < 8; i++) {
        board[0 + i * 8] = first[i];
        board[7 + i * 8] = first[i] + 8;
        board[1 + i * 8] = PAWN;
        board[6 + i * 8] = PAWN + 8;
        board[2 + i * 8] = 0;
        board[3 + i * 8] = 0;
        board[4 + i * 8] = 0;
        board[5 + i * 8] = 0;
    }
}
