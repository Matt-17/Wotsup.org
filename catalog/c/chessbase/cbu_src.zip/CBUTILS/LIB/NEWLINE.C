#include "global.h"

/*
 * NEWLINE
 *
 * Print a newline character
 */
int
newline()
{
    putchar('\n');
    return 0;
}
