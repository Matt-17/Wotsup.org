#include "global.h"

/*
 * SPACES
 *
 * Print a number of spaces.
 */
int
spaces(num)
    int num;
{
    int i;
    for (i = 0; i < num; i++)
        putchar(' ');
    return num;
}
