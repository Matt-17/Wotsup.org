#include "global.h"
#include <sys/stat.h>

/*
 * FILE_LENGTH
 *
 * Return the length of an open file
 */
u_long
file_length(fd)
    int fd;
{
    struct stat statbuf;

    if (fstat(fd, &statbuf) < 0)
        return 0;
    else
        return statbuf.st_size;
}
