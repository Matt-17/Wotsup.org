#include "global.h"

/*
 * KILL_EXT
 *
 * Remove the extension of a pathname.
 */
char *
kill_ext(path)
    char *path;
{
    register char *cptr;

    cptr = find_ext(path);
    if (!cptr)
        return NULL;
    *(cptr - 1) = '\0';
    return cptr;
}
