#include "global.h"

/*
 * XSTRDUP
 *
 * Duplicate strings.
 */
char *
xstrdup(s)
    char *s;
{
    char *ret;

    ret = mem_alloc(strlen(s) + 1);
    if (!ret)
        return NULL;
    strcpy(ret, s);
    return ret;
}
