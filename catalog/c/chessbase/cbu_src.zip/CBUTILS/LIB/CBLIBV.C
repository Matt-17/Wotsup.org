char *cblib_version = "1.0";
char *cblib_name = "ChessBase Library";
char *cblib_date = "22-Mar-1994 21:42";
int cblib_build = 6;
