#include "global.h"

/*
 * GAME_FREE
 *
 * Free a game structure
 */
void
game_free(game)
    Game game;
{
    game_tidy(game);
    free(game);
}
