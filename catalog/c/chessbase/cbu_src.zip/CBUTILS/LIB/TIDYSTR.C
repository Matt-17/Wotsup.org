#include "global.h"

/*
 * TIDY_STRING
 *
 * Remove excess spaces from a string.
 */
void
tidy_string(s)
    char *s;
{
    char *t, *cptr;
    int len;

    t = s;
    while (cptr = get_word(s, &len)) {
        if (cptr > t)
            strncpy(t, cptr, len);
        s = cptr + len;
        t += len;
        if (get_word(s, NULL))
            *t++ = ' ';
        else
            break;
    }
    *t = '\0';
}
