#include "global.h"

/*
 * ISFILELET
 *
 * Test if a character is a valid file letter.
 */
int
isfilelet(c)
	char c;
{
	return (c >= 'a' && c <= 'h');
}
