#include "global.h"

/*
 * KR_GETENTRY
 *
 * Convert an external (3-byte) entry into an unsigned long word.
 */
u_long
kr_getentry(xe)
    u_char *xe;
{
    u_long ret = 0L;

    ret = (u_long) * xe++ << 16;
    ret |= (u_long) * xe++ << 8;
    ret |= (u_long) * xe++;

    return ret;
}
