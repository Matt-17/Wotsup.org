#include "global.h"

/*
 * FILE_READ
 *
 * Read data from a file.
 */
int
file_read(file, buf, len)
    File file;
    char *buf;
    unsigned len;
{
    int nread;

    nread = read(file->fd, buf, len);
    if (nread == -1 || nread == 0)
        error("error reading file \"%s\" %s", file->name,
          nread == 0 ? "(EOF)" : "");
		
    return nread;
}
