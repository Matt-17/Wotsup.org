#include "global.h"

int no_error = 0;
