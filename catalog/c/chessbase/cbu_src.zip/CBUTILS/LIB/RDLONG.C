#include "global.h"

/*
 * READ_LONG
 *
 * Read a 4-byte value and convert it to local byte-sex.
 */
u_long
read_long(file)
    File file;
{
    u_char buf[4];

    if (file_read(file, (char *) buf, 4) != 4)
        return 0;
    return c2l(buf);
}
