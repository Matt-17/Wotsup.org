#include "global.h"

static char *prom_list = "QRBN";

/*
 * FORMAT_MOVE
 *
 * Return a string contains the text of a move.
 */
char *
format_move(from, to, prom)
	int from, to, prom;
{
    static char movetxt[8];

    movetxt[0] = to_file(from) + 'a';
    movetxt[1] = to_rank(from) + '1';
    movetxt[2] = to_file(to) + 'a';
    movetxt[3] = to_rank(to) + '1';
    if (prom) {
        movetxt[4] = '=';
        movetxt[5] = prom_list[prom];
        movetxt[6] = '\0';
    } else
        movetxt[4] = '\0';
    return movetxt;
}
