#include "global.h"
#include "syms.h"

/*
 * CVT_MOVEVAL
 *
 * Return the ASCII string for the given move evaluation symbol.
 */
char *
cvt_moveval(sym)
    int sym;
{
    if (sym > 0 && sym < NMOVEVALS)
        return moveval[sym];
    else
        return null;
}
