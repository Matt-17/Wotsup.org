#include "global.h"

u_char cb_board[64] = "";              /* board position */
int cb_enpassant;                      /* en-passant mask */
int comment;                           /* comment available from last move */
struct move lastmove;                  /* last move made */
int lastmove_num;                      /* index of last move in movelist */
u_short lastmove_flags;                /* interesting move flags (castle,
                                          etc.) */
struct move movelist[NMOVELIST] = {{0, 0, 0}};  /* list of legal moves
                                                   available */
int moveidx;                           /* end of movelist marker */
int var_level;                         /* variation level */
u_char captured_piece;                 /* piece just captured */
