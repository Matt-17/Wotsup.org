#include "global.h"
#include "syms.h"

/*
 * CVT_POSEVAL
 *
 * Return the ASCII string for the given position evaluation symbol.
 */
char *
cvt_poseval(sym)
    int sym;
{
    if (sym > 0 && sym < NPOSEVALS)
        return poseval[sym];
    else
        return null;
}
