#include "global.h"

/*
 * WRITE_LONG
 *
 * Write a 4-byte value converted from local byte-sex.
 */
int
write_long(file, value)
    File file;
    u_long value;
{
    u_char buf[4];

    l2c(buf, value);
    return file_write(file, (char *) buf, 4);
}
