#include "global.h"

/*
 * TEXT2PIECE
 *
 * convert an ASCII piece name into binary form
 */
u_char
text2piece(c)
    char c;
{
    register int i;
    int is_black;

    if (c >= 'a' && c <= 'z') {
        is_black = 1;
        c -= 'a' - 'A';
    } else {
        is_black = 0;
    }

    for (i = 0; i < 8; i++) {
        if (c == piece_list[i])
            return is_black ? i | 8 : i;
    }

    return 0xff;
}
