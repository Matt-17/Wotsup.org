#include "global.h"

/*
 * C2S
 *
 * Convert an array of bytes into an unsigned short in big-endian format.
 */
u_short
c2s(c)
    u_char *c;
{
    register u_short ret;

    ret = (u_short) * c++ << 8;
    ret |= (u_short) * c;
    return ret;
}
