#include "global.h"

/*
 * HIT_RETURN
 *
 * Ask user to hit return to continue;
 */
int
hit_return()
{
    int quit, c;

    printf("[Hit <CR> to continue, or Q<CR> to quit]");
    quit = 0;
    for (;;) {
        c = getchar();
        if (c == 'q')
            quit = 1;
        else if (c == '\n')
            break;
        else
            quit = 0;
    }
    return quit;
}
