#include "global.h"

/*
 * RENAME_DATABASE
 *
 * Rename the files associated with a database (.CBF and .CBI files).
 */
int
rename_database(db, newname)
    Database db;
    char *newname;
{
    if (file_rename(db->cbf, newname) < 0)
        return -1;
    if (file_rename(db->cbi, newname) < 0)
        return -1;
    return 0;
}
