#include "global.h"

/*
 * KR_PUTENTRY
 *
 * Convert an unsigned long word into an external (3-byte) entry.
 */
void
kr_putentry(value, xe)
    u_long value;
    u_char *xe;
{

    *xe++ = (u_char) (value >> 16);
    *xe++ = (u_char) (value >> 8);
    *xe = (u_char) value;
}
