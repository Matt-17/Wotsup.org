#include "global.h"

/*
 * WRITE_INDEX
 *
 * Write the index number for a game
 */
int
write_index(db, num, offset)
    Database db;
    u_long num, offset;
{
    file_seek(db->cbi, num * 4);
    offset += (num + 1);
    return write_long(db->cbi, offset);
}
