#include "global.h"
#include <ctype.h>

/*
 * STRLOWER
 *
 * Convert a string to lowercase
 */
void
strlower(s)
    register char *s;
{
    if (s) {
        while (*s) {
            *s = tolower(*s);
            s++;
        }
    }
}
