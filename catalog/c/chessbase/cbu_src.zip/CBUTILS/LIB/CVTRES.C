#include "global.h"
#include "syms.h"

/*
 * CVT_RESULT
 *
 * Convert a result byte into its ASCII equivalent.
 */
char *
cvt_result(res)
    int res;
{
    char *ret;

    switch (res) {
    case 0:
        ret = "0-1";
        break;
    case 1:
        ret = "1/2";
        break;
    case 2:
        ret = "1-0";
        break;
    default:
        ret = poseval[(res >> 2) & 0x0f];
        break;
    }
    return ret;
}
