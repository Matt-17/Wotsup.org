#include "global.h"

/*
 * L2C
 *
 * Convert an unsigned long to an array of bytes in big-endian format
 */
void
l2c(c, value)
    u_char *c;
    u_long value;
{
    *c++ = (u_char) (value >> 24);
    *c++ = (u_char) (value >> 16);
    *c++ = (u_char) (value >> 8);
    *c = (u_char) (value);
}
