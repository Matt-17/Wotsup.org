char *piece_list = "-KQNBRP*";
