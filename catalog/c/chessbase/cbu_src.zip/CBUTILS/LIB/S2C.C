#include "global.h"

/*
 * S2C
 *
 * Convert an unsigned short to an array of bytes in big-endian format
 */
void
s2c(c, value)
    u_char *c;
    u_short value;
{
    *c++ = (u_char) (value >> 8);
    *c = (u_char) (value);
}
