#include "global.h"

/*
 * READ_INDEX
 *
 * Read the index number for a game
 */
u_long
read_index(db, num)
    Database db;
    u_long num;
{
    file_seek(db->cbi, num * 4);
    return read_long(db->cbi) - (num + 1);
}
