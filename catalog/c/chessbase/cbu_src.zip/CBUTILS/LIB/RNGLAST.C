#include "global.h"
#include <ctype.h>

u_long
range_last(string)
    char *string;
{
    char *cptr, *endptr;
    u_long ret;

    cptr = index(string, '-');
    if (cptr) {
        cptr++;
        if (index(cptr, '-'))
            return 0L;
    } else {
        cptr = string;
    }
    if (isdigit(*cptr)) {
        ret = (u_long) strtol(cptr, &endptr, 10);
        if (*endptr != '\0')
            return 0L;
        return ret;
    } else if (*cptr == '\0')
        return 0xfffffffL;
    return 0L;
}
