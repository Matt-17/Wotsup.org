#include "global.h"

/*
 * FILE_WRITE
 *
 * Write data to a file.
 */
int 
file_write(file, buf, len)
    File file;
    char *buf;
    unsigned len;
{
    unsigned nwrote;

    nwrote = write(file->fd, buf, len);
    if (nwrote != len)
        error("error writing file \"%s\"", file->name);
    return nwrote;
}
