#include "global.h"

int mem_alloc_err = 0;

/*
 * MEM_ALLOC
 *
 * Allocate memory with error-checking.
 */
char *
mem_alloc(len)
    unsigned len;
{
    register char *ret;

    ret = malloc(len);
    if (!ret) {
        error("memory exhausted");
		mem_alloc_err++;
        return NULL;
    }
    bzero(ret, len);
    return ret;
}
