#include "global.h"

/*
 * FIND_EXT
 *
 * Locate the extension of a pathname.
 */
char *
find_ext(path)
    char *path;
{
    register char *cptr;

    cptr = rindex(path, PATHSEP);
    if (!cptr)
        cptr = path;
    cptr = rindex(cptr, '.');
    if (!cptr)
        return NULL;
    return cptr + 1;
}
