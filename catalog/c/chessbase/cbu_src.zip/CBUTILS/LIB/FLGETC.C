#include "global.h"

/*
 * FILE_GETC
 *
 * Get a character from a file.
 */
int
file_getc(file)
    File file;
{
    int ret;
    char buffer;

    ret = read(file->fd, &buffer, 1);
    if (ret != 1)
        error("error reading file \"%s\" %s", file->name,
          ret == 0 ? "(EOF)" : "");
    return buffer;
}
