#include "global.h"

/*
 * FORMAT_MOVENUM
 *
 * Return text in the form "XX." or "XX..." depending on the move number.
 */
char *
format_movenum(halfmove)
    unsigned halfmove;
{
    static char buf[8];

    sprintf(buf, "%d%s ", to_move(halfmove),
      to_colour(halfmove) ? "..." : ".");
    return buf;
}
