#include "global.h"

/*
 * WRITE_NGAMES
 *
 * Write the "number of games" value to the start of the index file.
 */
int
write_ngames(db)
    Database db;
{
    file_seek(db->cbi, 0L);
    return write_long(db->cbi, db->ngames + 1);
}
