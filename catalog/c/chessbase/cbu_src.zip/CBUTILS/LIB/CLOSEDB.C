#include "global.h"

/*
 * CLOSE_DATABASE
 *
 * Close an open database.
 */
int
close_database(db)
    Database db;
{
    if (!db)
        return -1;
    if (db->cbf)
        file_close(db->cbf);
    if (db->cbi)
        file_close(db->cbi);
    free(db);
    return 0;
}
