#include "global.h"

/*
 * USTRLEN
 *
 * Return the length of a string of unsigned characters
 */
unsigned
ustrlen(us)
    u_char *us;
{
    unsigned ret = 0;

    while (*us++)
        ret++;
    return ret;
}
