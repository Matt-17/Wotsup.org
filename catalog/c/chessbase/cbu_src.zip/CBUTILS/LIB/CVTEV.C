#include "global.h"
#include "syms.h"

/*
 * CVT_EVAL
 *
 * Return the ASCII string for the given evaluation symbol.
 */
char *
cvt_eval(sym)
    int sym;
{
    if (sym > 0 && sym < NEVALS)
        return eval[sym];
    else
        return null;
}
