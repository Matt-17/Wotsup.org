#include "global.h"

/*
 * READ_NGAMES
 *
 * Read the "number of games" value from the start of the index file.
 */
int
read_ngames(db)
    Database db;
{
    file_seek(db->cbi, 0L);
    db->ngames = read_long(db->cbi) - 1;
    return 0;
}
