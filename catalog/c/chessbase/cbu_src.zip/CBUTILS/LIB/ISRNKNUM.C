#include "global.h"

/*
 * ISRANKNUM
 *
 * Test if a character is a valid rank number.
 */
int
isranknum(c)
	char c;
{
	return (c >= '1' && c <= '8');
}
