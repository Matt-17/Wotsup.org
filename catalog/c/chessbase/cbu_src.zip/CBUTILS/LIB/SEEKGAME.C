#include "global.h"

/*
 * SEEK_GAME
 *
 * Seek game file pointer to correct location for a game.
 */
void
seek_game(db, game)
    Database db;
    Game game;
{
    long offset;

    offset = read_index(db, game->num);
    file_seek(db->cbf, offset);
}
