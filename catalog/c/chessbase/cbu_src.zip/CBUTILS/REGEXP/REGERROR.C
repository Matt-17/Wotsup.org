#include <regexp.h>
#include <stdio.h>
#include "global.h"

void
regerror(s)
    const char *s;
{
    error("regexp: %s", s);
}
