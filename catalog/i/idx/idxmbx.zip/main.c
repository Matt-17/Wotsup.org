/***************************************************************************
 * Microsoft Outlook Express File Format Decoder
 ***************************************************************************
 *
 * Copyright (c) 1998 Tom Gallagher
 * Email: teg@cableinet.co.uk
 ***************************************************************************
 */
#include <stdio.h>
#include <malloc.h>
#include <time.h>

#include "outlook.h"

int main(int argc,char **argv)
{
    int i;
    MAILBOX *pMBox;

    printf("Outlook IDX & MBX decoder by Tom Gallagher (teg@cableinet.co.uk)\n");

    if (argc != 2) {
        printf("Usage: %s mailbox\n",argv[0]);
        printf("e.g. %s c:\\outlook\\mail\\inbox",argv[0]);
        return 0;
    }
                
    if (NULL == (pMBox = OpenMailBox(argv[1])))
    {
        printf("OpenMailBox returned an error\n");
        return 0;
    }

    
    for(i=0;i<pMBox->IdxHdr.nItems;i++)
    {
        printf("%s\n",pMBox->pMsgs[i].Subject.Data);
    }
    
    CloseMailBox(pMBox);
}






