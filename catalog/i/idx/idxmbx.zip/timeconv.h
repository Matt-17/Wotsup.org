#ifndef __TIMECONV_H
#define __TIMECONV_H

#include "common.h"

#include <time.h>


time_t FileTimeToUnixTime( const FILETIME *filetime, DWORD *remainder );

#endif
