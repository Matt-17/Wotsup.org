
#ifndef __COMMON_H
#define __COMMON_H

typedef unsigned int DWORD;
typedef unsigned short int WORD;
typedef unsigned char BYTE;

typedef unsigned int UINT32;

#pragma pack (1)



#define FALSE 0
#define TRUE 1

typedef struct {

	DWORD dwLowDateTime;
    DWORD dwHighDateTime;




} FILETIME;

#endif
        